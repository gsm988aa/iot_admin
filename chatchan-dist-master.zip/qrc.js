const express = require('express');
const qrcode = require('qrcode');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.get('/qrcode', (req, res) => {
  const text = req.query.text;
  qrcode.toFile(__dirname + '/public/qrcode.png', text, (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('生成二维码失败');
    } else {
      res.sendFile(__dirname + '/public/qrcode.png');
    }
  });
});

io.on('connection', (socket) => {
  console.log('a user connected');

  socket.on('disconnect', () => {
    console.log('user disconnected');
  });

  socket.on('message', (message) => {
    console.log('message:', message);
    io.emit('message', message);
  });
});

server.listen(3000, () => {
  console.log('Server is running on port 3000');
});