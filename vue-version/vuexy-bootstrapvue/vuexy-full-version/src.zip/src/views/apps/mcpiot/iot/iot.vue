<template>
  <b-card title="ChatGPT解决专业问题">

    <b-card-text>
<!--改变这个card的颜色-->


    <h6>GPT 人工智能回复：</h6>
      <b-card

        text-variant="dark"
        border-variant="info"
        class="mb-2"
      >

            <b-card-text>
<!--           字体加粗-->


              <br>
                <b-spinner variant="primary" label="Spinning"  v-if="status !== 1"></b-spinner>

              {{ posts }}

            </b-card-text>
      </b-card>



    </b-card-text>
          <br>

<!--    -->
    <h6>请输入问题</h6>
    <b-form-input
      v-model="message"
      placeholder="请输入问题"
    />
          <br>

    <b-button
      variant="primary" pill
      @click="send"
    >

      发送
    </b-button>

  </b-card>


<!--&lt;!&ndash;      写一个可以输入的文本框&ndash;&gt;-->
<!--      <input type="text" v-model="message" />-->
<!--&lt;!&ndash;      点击按钮发送&ndash;&gt;-->
<!--      <button @click="send">发送</button>-->


</template>

<script>

import {
 BRow, BCol, BCard, BContainer, BButton, BButtonGroup, BFormInput, BModal,BSpinner
, BCollapse } from 'bootstrap-vue'
// import axios
import axios from 'axios'
import Spinner from "@/views/components/spinner/Spinner.vue";
export default {
  components: {
    BSpinner,
    BRow,
    BCol,
    BCard,
    BButton,
    // eslint-disable-next-line vue/no-unused-components
    BButtonGroup,
    // b-container
    BContainer,
    BFormInput,
    BModal,
    BCollapse,
  },
  data() {
    return {
      message: '',
      status: 1,
      posts: ''
    };
  },

  methods: {
    send() {
      axios.post('https://openai.api2d.net/v1/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: [{role: 'user', content: this.message}]
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer fk192265-ZSVj6ZJGVn2Na3lm0Ouz5S0PZ7NrMRxA'
        }
      }).then(response => {
        // 等待5s
        setTimeout(() => {
          this.status = 1
          this.posts = response.data.choices[0].message.content
          console.log(response.data.choices[0].message.content)
          // console.log(response.data)
        }, 3000);
        this.status = 0

      })
          .catch(error => {
            console.log(error);
          });
    }
}

};

</script>
