<template>

</template>

<script>
export default {
  name: 'othersettings'
}
</script>

<style scoped>

</style>
