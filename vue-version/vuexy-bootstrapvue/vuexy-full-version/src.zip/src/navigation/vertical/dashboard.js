export default [
  {
    title: 'Dashboards',
    icon: 'HomeIcon',
    tag: '2',
    tagVariant: 'light-warning',
    children: [
      // {
      //   title: 'eCommerce',
      //   route: 'dashboard-ecommerce',
      // },
      // {
      //   title: 'Analytics',a
      //   route: 'dashboard-analytics',
      // },
      {
        title: 'Deviceinfos',
        route: 'dashboard-deviceinfos',
      },
      {
        title: 'Userinfos',
        route: 'dashboard-userinfos',
      }

    ],
  },
]
