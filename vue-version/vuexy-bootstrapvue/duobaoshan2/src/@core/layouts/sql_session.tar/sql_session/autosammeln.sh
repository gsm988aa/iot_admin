#!bin/bash 
python3 /root/Desktop/it_cb/pyDB_test/serial_sqlite.py

