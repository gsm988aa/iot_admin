# pyDB
python3
pyserial
#pymysql

apt install python3-pip
pip install pyserial pysqlite3 serial
