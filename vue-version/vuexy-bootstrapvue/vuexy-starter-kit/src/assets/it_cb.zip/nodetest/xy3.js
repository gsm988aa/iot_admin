const express = require('express');
const app = express();
const cors = require("cors")
const { SerialPort } = require('serialport')
const serialport2 = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 115200}, function (err) {
  if (err) {
    return console.log('Error: ', err.message)
  }
})


var port = 10866;

// var arduinoCOMPort ="COM2";

// var serialport2 = new SerialPort(arduinoCOMPort, {
//  baudrate: 921600
// });


app.use(
  cors({
    origin: ["http://localhost:10866","http://localhost:8080","http://192.168.0.109:8080","http://192.168.3.103:8080"]
  })
);


function hex(str) {
  var arr = [];
  for (var i = 0, l = str.length; i < l; i ++) {
    var ascii = str.charCodeAt(i);
    arr.push(ascii);
  }
  arr.push(255);
  arr.push(255);
  arr.push(255);
  return new Buffer(arr);
}


serialport2.write('main screen turn on', function(err) {
  if (err) {
    return console.log('Error on write:', err.message)
  }
  console.log('message written')
})



var senddata = [0x01,0x02];

//senddata ='test data';

function writeport()
{
  serialport2.write(senddata, function (err) {
    if (err) {
      return console.log('Error on write:', err.message);
    }
    console.log('send:'+ senddata);
  });
}

serialport2.on('open', function () {
  writeport();
});

// open errors will be emitted as an error event
serialport2.on('error', function (err) {
  console.log('Error:', err.message);
})

// setInterval(function () {
//     writeport();
// }, 1000);


serialport2.on('data', function (data,res) {

  // console.log('recv:'+ data.toString('hex','hex');

  console.log('recv:'+ data );
  if (data == 'Test1') {
    console.log('recv:'+ ' = 1' );
  }
  else if (data == 'Test2') {
     console.log('recv:'+ ' = 2' );
  }
    else if (data == 'Test3') {
     console.log('recv:'+ ' = 3' );
  }
    else if (data == 'Test4') {
        console.log('recv:'+ ' = 4' );

  }
    else if (data == 'Test5') {
        console.log('recv:'+ ' = 5' );
  }
    else if (data == 'Test6') {
        console.log('recv:'+ ' = 6' );
    senddata ='test6';
  }
    else if (data == 'Test7') {
        console.log('recv:'+ ' = 7' );
    senddata ='test7';
    }
    else if (data == 'Test8') {
        console.log('recv:'+ ' = 8' );
    senddata ='test8';
    }
    else if (data == 'Testok') {
        console.log('recv:'+ ' = ok' );
    }
    else if (data == 'Testcc') {
        console.log('recv:'+ ' = cc' );
    }
  });



serialport2.on('open',function() {
  console.log('Serial Port'+' ttyUSB0 '+'is opened.');
});

app.get('/', function (req, res) {

  return res.send('Working');

})

app.get('/:action', function (req, res) {

  var action = req.params.action || req.param('action');

  if(action =='led'){
    serialport2.write("ledget");
    return res.send("Led light is on!!!");

  }
  if(action =='off') {
    serialport2.write("off");
    return res.send("Led light is off!");
  }

  return res.send('Action:'+ action);

});

app.post('/:action', function (req, res) {

  var action = req.params.action || req.param('action');

  if(action =='led2'){
    serialport2.write("ledget");
    return res.send("Led light is on!!!");
  }

  if(action =='led'){
    serialport2.write('01 05 09 00 FF 00 8F A6','hex');
    return res.send("Led light is on!!!");
  }



  if(action=="yaokonghezha"){
    serialport2.write('01050900FF008FA6','hex');
    return res.send(senddata);
  }
  if(action=="yaokongfenzha"){
    serialport2.write('01050901FF00DE66','hex');
    return res.send(senddata);
  }
  if(action=="yaokongfugui"){
    serialport2.write('01050902FF002E66','hex');
    return res.send("Ledlightison!!!");
  }


  if(action=='off'){
    serialport2.write("off");
    return res.send("Ledlightisoff!");
  }

  return res.send('Action:'+action);

});


app.listen(port,function(){
  console.log('Example applistening on port http://127.0.0.1:'+port+'!');
});

