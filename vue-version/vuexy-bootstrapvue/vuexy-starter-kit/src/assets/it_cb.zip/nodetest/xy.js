const express = require('express');
const app = express();
const cors = require("cors")
const { SerialPort } = require('serialport')
const serialport2 = new SerialPort({ path:'COM2', baudRate: 921600}, function (err) {
  if (err) {
    return console.log('Error:', err.message)
  }
})


var port = 10866;

// var arduinoCOMPort ="COM2";

// var serialport2 = new SerialPort(arduinoCOMPort, {
//  baudrate: 921600
// });


app.use(
    cors({
        origin: ["http://localhost:10866","http://localhost:8080","http://192.168.0.109:8080","http://192.168.3.103:8080"]
    })
);


function hex(str) {
        var arr = [];
        for (var i = 0, l = str.length; i < l; i ++) {
                var ascii = str.charCodeAt(i);
                arr.push(ascii);
        }
        arr.push(255);
        arr.push(255);
        arr.push(255);
        return new Buffer(arr);
}


serialport2.write('main screen turn on', function(err) {
  if (err) {
    return console.log('Error on write:', err.message)
  }
  console.log('message written')
})


//��hex
var senddata = [0x01,0x02];
//���ַ���
//senddata ='test data';

function writeport()
{
    serialport2.write(senddata, function (err) {
        if (err) {
            return console.log('Error on write:', err.message);
        }
        console.log('send:'+ senddata);
    });
}

serialport2.on('open', function () {
    writeport();
});

// open errors will be emitted as an error event
serialport2.on('error', function (err) {
    console.log('Error:', err.message);
})

// setInterval(function () {
//     writeport();
// }, 1000);


serialport2.on('data', function (data) {
    //��hex
    // console.log('recv:'+ data.toString('hex','hex');
    //���ַ���
    console.log('recv:'+ data );
  });



serialport2.on('open',function() {
  console.log('Serial Port'+'COM2'+'is opened.');
});

app.get('/', function (req, res) {

    return res.send('Working');

})

app.get('/:action', function (req, res) {

   var action = req.params.action || req.param('action');

    if(action =='led'){
        serialport2.write("ledget");
         return res.send("Led light is on!!!");

    }
    if(action =='off') {
        serialport2.write("off");
        return res.send("Led light is off!");
    }

    return res.send('Action:'+ action);

});

app.post('/:action', function (req, res) {

   var action = req.params.action || req.param('action');

    if(action =='led2'){
         serialport2.write("ledget");
         return res.send("Led light is on!!!");
    }

    if(action =='led'){
         serialport2.write('01 05 09 00 FF 00 8F A6','hex');
         return res.send("Led light is on!!!");
    }


//��¼1
    if(action =="dianliuhuganqibianbi"){
         serialport2.write('010300000001840A','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="dian liu hu gan qi bian bi"){
         serialport2.write('010300000001840A','hex');
         return res.send("Led light is on!!!");
    }
    if(action =="ping bao can shu she zhi"){
         serialport2.write('01 03 00 01 00 01 D5 CA','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="dian ya hu gan qi bian bi"){
         serialport2.write('01 03 00 02 00 01 25 CA','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="he zha ji dian qi mo chong kuan du"){
         serialport2.write('01 03 00 03 00 01 74 0A','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="tiao zha ji dian qi mo chong kuan du"){
         serialport2.write('01 03 00 04 00 01 C5 CB','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 1lue bo shi jian"){
         serialport2.write('01 03 00 05 00 01 94 0B','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 2lue bo shi jian"){
         serialport2.write('01 03 00 06 00 01 64 0B','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 3lue bo shi jian"){
         serialport2.write('01 03 00 07 00 01 35 CB','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 4lue bo shi jian"){
         serialport2.write('01 03 00 08 00 01 05 C8','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 5lue bo shi jian"){
         serialport2.write('01 03 00 09 00 01 54 08','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 6lue bo shi jian"){
         serialport2.write('01 03 00 0A 00 01 A4 08','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 7lue bo shi jian"){
         serialport2.write('01 03 00 0B 00 01 F5 C8','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kai ru liang 8lue bo shi jian"){
         serialport2.write('01 03 00 0C 00 01 44 09','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="CANtong xun bo te lue"){
         serialport2.write('01 03 00 0D 00 01 15 C9','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="CANtong xun di zhi"){
         serialport2.write('01 03 00 0E 00 01 E5 C9','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="RS485bo te lue"){
         serialport2.write('01 03 00 0F 00 01 B4 09','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="RS485tong xun di zhi"){
         serialport2.write('01 03 00 10 00 01 85 CF','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="you gong dian du mo chong ji shu"){
         serialport2.write('01 03 00 11 00 01 D4 0F','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="wu gong dian du mo chong ji shu"){
         serialport2.write('01 03 00 12 00 01 24 0F','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="gu zhang lu bo fu gui fang shi"){
         serialport2.write('01 03 00 13 00 01 75 CF','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="can shu she ding mi ma"){
         serialport2.write('01 03 00 14 00 01 C4 0E','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Main CPUban ben"){
         serialport2.write('01 03 00 15 00 01 95 CE','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Com CPUban ben"){
         serialport2.write('01 03 00 16 00 01 65 CE','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="dian ji qi dong xuan ze"){
         serialport2.write('01 03 00 17 00 01 34 0E','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="dian ji e ding dian liu"){
         serialport2.write('01 03 00 18 00 01 04 0D','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="lou dian ji dian qi mo chong shi jian"){
         serialport2.write('01 03 00 19 00 01 55 CD','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="jue yuan ji dian qi mo chong shi jian"){
         serialport2.write('01 03 00 1A 00 01 A5 CD','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="gong lue ji suan fang shi"){
         serialport2.write('01 03 00 1B 00 01 F4 0D','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="dan wei bi suo shi jian"){
         serialport2.write('01 03 00 1C 00 01 45 CC','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="su duan jie suo dian liu"){
         serialport2.write('01 03 00 1D 00 01 14 0C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="jia re chu shi ji dian qi mo chong shi jian"){
         serialport2.write('01 03 00 1E 00 01 E4 0C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="shi ya yan shi ji dian qi mo chong shi jian"){
         serialport2.write('01 03 00 1F 00 01 B5 CC','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ruan fu wei ci shu"){
         serialport2.write('01 03 00 20 00 01 85 C0','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ying fu wei ci shu"){
         serialport2.write('01 03 00 21 00 01 D4 00','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="bei yong 1"){
         serialport2.write('01 03 00 22 00 01 24 00','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="bei yong 2"){
         serialport2.write('01 03 00 23 00 01 75 C0','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gu zhang biao zhi xin xi"){
         serialport2.write('01 03 00 24 00 01 C4 01','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="PDPban ben xin xi"){
         serialport2.write('01 03 00 25 00 06 D4 03','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="Com Bootban ben xin xi"){
         serialport2.write('01 03 00 2B 00 01 F4 02','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ye jing dui bi du"){
         serialport2.write('01 03 00 2D 00 01 14 03','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gu zhang biao zhi xin xi"){
         serialport2.write('01 03 00 2E 00 02 A4 02','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="he zha ci shu tong ji"){
         serialport2.write('01 03 00 58 00 01 05 D9','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fen zha ci shu tong ji"){
         serialport2.write('01 03 00 59 00 01 54 19','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="yuan cheng dian zi gua pai"){
         serialport2.write('01 03 00 5A 00 01 A4 19','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang Iaji xing qu fan"){
         serialport2.write('01 03 00 5B 00 01 F5 D9','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang Icji xing qu fan"){
         serialport2.write('01 03 00 5C 00 01 44 18','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="bao hu IAji xing qu fan"){
         serialport2.write('01 03 00 5D 00 01 15 D8','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="bao hu ICji xing qu fan"){
         serialport2.write('01 03 00 5E 00 01 E5 D8','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="zhu dong fa song lu bo shi neng"){
         serialport2.write('01 03 00 5F 00 01 B4 18','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fang yue ji bi suo chi xu shi jian"){
         serialport2.write('01 03 00 60 00 01 84 14','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="SU31kuo zhan ji dian qi 1chu kou mo chong"){
         serialport2.write('01 03 00 61 00 01 D5 D4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="SU31kuo zhan ji dian qi 2chu kou mo chong"){
         serialport2.write('01 03 00 62 00 01 25 D4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="SU31kuo zhan ji dian qi 3chu kou mo chong"){
         serialport2.write('01 03 00 63 00 01 74 14','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="SU31kuo zhan ji dian qi 4chu kou mo chong"){
         serialport2.write('01 03 00 64 00 01 C5 D5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang Ibji xing qu fan"){
         serialport2.write('01 03 00 65 00 01 94 15','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="bao hu IBji xing qu fan"){
         serialport2.write('01 03 00 66 00 01 64 15','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ben ti kuo zhan ji dian qi 1chu kou mo chong"){
         serialport2.write('01 03 00 67 00 01 35 D5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ben ti kuo zhan ji dian qi 2chu kou mo chong"){
         serialport2.write('01 03 00 68 00 01 05 D6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ben ti kuo zhan ji dian qi 3chu kou mo chong"){
         serialport2.write('01 03 00 69 00 01 54 16','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ben ti kuo zhan ji dian qi 4chu kou mo chong"){
         serialport2.write('01 03 00 6A 00 01 A4 16','hex');
         return res.send("Led light is on!!!");
    }




//��¼2
 if(action =="su duan bao hu dian liu ding zhi"){
         serialport2.write('01 03 01 00 00 01 85 F6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="xian shi su duan bao hu dian liu ding zhi"){
         serialport2.write('01 03 01 01 00 01 D4 36','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="xian shi su duan bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 02 00 01 24 36','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ding shi xian guo liu bao hu dian liu ding zhi"){
         serialport2.write('01 03 01 03 00 01 75 F6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ding shi xian guo liu bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 04 00 01 C4 37','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fan shi xian guo liu bao hu dian liu ding zhi"){
         serialport2.write('01 03 01 05 00 01 95 F7','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fan shi xian guo liu bao hu shi jian bei shu"){
         serialport2.write('01 03 01 06 00 01 65 F7','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fan shi xian qu xian zhong lei"){
         serialport2.write('01 03 01 07 00 01 34 37','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ling xu guo liu bao hu dian liu ding zhi"){
         serialport2.write('01 03 01 08 00 01 04 34','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ling xu guo liu bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 09 00 01 55 F4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="NULL1"){
         serialport2.write('01 03 01 0A 00 01 A5 F4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="NULL2"){
         serialport2.write('01 03 01 0B 00 01 F4 34','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gong lue fang xiang ling xu guo liu bao hu ding zhi"){
         serialport2.write('01 03 01 0C 00 01 45 F5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gong lue fang xiang ling xu guo liu bao hu shi jian"){
         serialport2.write('01 03 01 0D 00 01 14 35','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di dian ya bao hu dian ya ding zhi"){
         serialport2.write('01 03 01 0E 00 01 E4 35','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di dian ya bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 0F 00 01 B5 F5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="guo dian ya bao hu dian ya ding zhi"){
         serialport2.write('01 03 01 10 00 01 84 33','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="guo dian ya bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 11 00 01 D5 F3','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ling xu guo dian ya bao hu dian ya ding zhi"){
         serialport2.write('01 03 01 12 00 01 25 F3','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="jue yuan dian zu jian ce dian zu di ding zhi"){
         serialport2.write('01 03 01 14 00 01 C5 F2','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="jue yuan dian zu jian ce dian zu gao ding zhi"){
         serialport2.write('01 03 01 15 00 01 94 32','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="jue yuan dian zu jian ce shi jian ding zhi"){
         serialport2.write('01 03 01 16 00 01 64 32','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="PTduan xian bao jing yan shi shi jian"){
         serialport2.write('01 03 01 17 00 01 35 F2','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="kai ru bao hu yan shi ding zhi"){
         serialport2.write('01 03 01 18 00 01 05 F1','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fu lu 2NULL"){
         serialport2.write('01 03 01 19 00 01 54 31','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gao wen tiao zha bao hu wen du ding zhi"){
         serialport2.write('01 03 01 1A 00 01 A4 31','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gao wen tiao zha bao hu shi jian"){
         serialport2.write('01 03 01 1B 00 01 F5 F1','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="jia re chu shi bao hu shi du ding zhi"){
         serialport2.write('01 03 01 1C 00 01 44 30','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="shi ya bao hu dian ya ding zhi"){
         serialport2.write('01 03 01 1D 00 01 15 F0','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="shi ya bao hu shi jian ding zhi"){
         serialport2.write('01 03 01 1E 00 01 E5 F0','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="xian quan jie di ling xu guo liu bao hu ding zhi"){
         serialport2.write('01 03 01 1F 00 01 B4 30','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="xian quan jie di ling xu guo liu bao hu shi jian"){
         serialport2.write('01 03 01 20 00 01 84 3C','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="xian quan jie di ling xu guo ya bao hu ding zhi"){
         serialport2.write('01 03 01 21 00 01 D5 FC','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="gong lue fang xiang bi suo ling xu"){
         serialport2.write('01 03 01 22 00 01 25 FC','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fu lu 2bei yong"){
         serialport2.write('01 03 01 23 00 01 74 3C','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="2ci xie bo bi suo su duan"){
         serialport2.write('01 03 01 24 00 01 C5 FD','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="2ci xie bo bi suo xian shi su duan"){
         serialport2.write('01 03 01 25 00 01 94 3D','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="2ci xie bo bi suo ding shi xian guo liu"){
         serialport2.write('01 03 01 26 00 01 64 3D','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="er ci xie bo bi suo xi shu"){
         serialport2.write('01 03 01 27 00 01 35 FD','hex');
         return res.send("Led light is on!!!");
    }

//��¼3
 if(action =="ce liang you gong dian du"){
         serialport2.write('01 03 02 00 00 01 85 B2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ce liang wu gong dian du"){
         serialport2.write('01 03 02 02 00 01 24 72','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="mo chong you gong dian du"){
         serialport2.write('01 03 02 04 00 01 C4 73','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="mo chong wu gong dian du"){
         serialport2.write('01 03 02 06 00 01 65 B3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ce liang jian you gong dian du"){
         serialport2.write('01 03 02 08 00 01 04 70','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang jian wu gong dian du"){
         serialport2.write('01 03 02 0A 00 01 A5 B0','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang feng you gong dian du"){
         serialport2.write('01 03 02 0C 00 01 45 B1','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ce liang feng wu gong dian du"){
         serialport2.write('01 03 02 0E 00 01 E4 71','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang gu you gong dian du"){
         serialport2.write('01 03 02 10 00 01 84 77','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ce liang gu wu gong dian du"){
         serialport2.write('01 03 02 12 00 01 25 B7','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang ping you gong dian du"){
         serialport2.write('01 03 02 14 00 01 C5 B6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="ce liang ping wu gong dian du"){
         serialport2.write('01 03 02 16 00 01 64 76','hex');
         return res.send("Led light is on!!!");
    }

//��¼4
//��¼5
 if(action =="di 0ci shi jian ma"){
         serialport2.write('01 03 04 00 00 01 85 3A','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian fan hui zhi"){
         serialport2.write('01 03 04 01 00 01 D4 FA','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����hao miao"){
         serialport2.write('01 03 04 02 00 01 24 FA','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����fen zhong"){
         serialport2.write('01 03 04 03 00 01 75 3A','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����xiao shi"){
         serialport2.write('01 03 04 04 00 01 C4 FB','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����gu zhang lu bo hao ��di zi jie ��+ri qi ��di zi jie ��"){
         serialport2.write('01 03 04 05 00 01 95 3B','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����gu zhang lu bo hao ��gao zi jie ��+yue ��di zi jie ��"){
         serialport2.write('01 03 04 06 00 01 65 3B','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����nian"){
         serialport2.write('01 03 04 07 00 01 34 FB','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian ma"){
         serialport2.write('01 03 04 F0 00 01 85 09','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian fan hui zhi"){
         serialport2.write('01 03 04 F1 00 01 D4 C9','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����hao miao"){
         serialport2.write('01 03 04 F2 00 01 24 C9','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����fen zhong"){
         serialport2.write('01 03 04 F3 00 01 75 09'),'hex';
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����xiao shi"){
         serialport2.write('01 03 04 F4 00 01 C4 C8','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����gu zhang lu bo hao ��di zi jie ��+ri qi ��di zi jie ��"){
         serialport2.write('01 03 04 F5 00 01 95 08','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����gu zhang lu bo hao ��gao zi jie ��+yue ��di zi jie ��"){
         serialport2.write('01 03 04 F6 00 01 65 08','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����nian"){
         serialport2.write('01 03 04 F7 00 01 34 C8','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="dang qian zui xin shi jian zhi zhen"){
         serialport2.write('01 03 04 F8 00 01 04 CB','hex');
         return res.send("Led light is on!!!");
    }

//��¼6

 if(action =="di 0ci xi tong shi jian ma"){
         serialport2.write('01 03 05 00 00 01 84 C6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci gu zhang fan hui zhi"){
         serialport2.write('01 03 05 01 00 01 D5 06','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci gu zhang shi jian ����miao"){
         serialport2.write('01 03 05 02 00 01 25 06','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci gu zhang shi jian ����fen zhong"){
         serialport2.write('01 03 05 03 00 01 74 C6','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci gu zhang shi jian ����xiao shi"){
         serialport2.write('01 03 05 04 00 01 C5 07','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����gu zhang lu bo hao ��di zi jie ��+ri qi ��di zi jie ��"){
         serialport2.write('01 03 05 05 00 01 94 C7','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci shi jian shi jian ����gu zhang lu bo hao ��gao zi jie ��+yue ��di zi jie ��"){
         serialport2.write('01 03 05 06 00 01 64 C7','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 0ci gu zhang shi jian ����nian"){
         serialport2.write('01 03 05 07 00 01 35 07','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang ma"){
         serialport2.write('01 03 05 F0 00 01 84 F5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang fan hui zhi"){
         serialport2.write('01 03 05 F1 00 01 D5 35','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang shi jian ����miao"){
         serialport2.write('01 03 05 F2 00 01 25 35','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang shi jian ����fen zhong"){
         serialport2.write('01 03 05 F3 00 01 74 F5','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang shi jian ����xiao shi"){
         serialport2.write('01 03 05 F4 00 01 C5 34','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����gu zhang lu bo hao ��di zi jie ��+ri qi ��di zi jie ��"){
         serialport2.write('01 03 05 F5 00 01 94 F4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci shi jian shi jian ����gu zhang lu bo hao ��gao zi jie ��+yue ��di zi jie ��"){
         serialport2.write('01 03 05 F6 00 01 64 F4','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="di 30ci gu zhang shi jian ����nian"){
         serialport2.write('01 03 05 F7 00 01 35 34','hex');
         return res.send("Led light is on!!!");
    }
 if(action =="fu lu 6dang qian zui xin shi jian zhi zhen"){
         serialport2.write('01 03 05 F8 00 01 05 37','hex');
         return res.send("Led light is on!!!");
    }

//��¼7
 if(action =="Axiang ce liang dian liu"){
         serialport2.write('01 03 06 00 00 01 84 82','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Bxiang ce liang dian liu"){
         serialport2.write('01 03 06 01 00 01 D5 42','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Cxiang ce liang dian liu"){
         serialport2.write('01 03 06 02 00 01 25 42','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Axiang ce liang dian ya"){
         serialport2.write('01 03 06 03 00 01 74 82','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Bxiang ce liang dian ya"){
         serialport2.write('01 03 06 04 00 01 C5 43','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Cxiang ce liang dian ya"){
         serialport2.write('01 03 06 05 00 01 94 83','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ABxian ce liang dian ya"){
         serialport2.write('01 03 06 06 00 01 64 83','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="BCxian ce liang dian ya"){
         serialport2.write('01 03 06 07 00 01 35 43','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="CAxian ce liang dian ya"){
         serialport2.write('01 03 06 08 00 01 05 40','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="U0ce liang dian ya"){
         serialport2.write('01 03 06 09 00 01 54 80','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="lou dian ce liang dian liu"){
         serialport2.write('01 03 06 0A 00 01 A4 80','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 7ce liang you gong gong lue"){
         serialport2.write('01 03 06 0B 00 01 F5 40','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 7ce liang wu gong gong lue"){
         serialport2.write('01 03 06 0C 00 01 44 81','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 7ce liang shi zai gong lue"){
         serialport2.write('01 03 06 0D 00 01 15 41','hex');
         return res.send("Led light is on!!!");
    }

//��¼8

//��¼9

//��¼10
  if(action =="yao kong he zha"){
         serialport2.write('01 05 09 00 FF 00 8F A6','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="yao kong fen zha"){
         serialport2.write('01 05 09 01 FF 00 DE 66','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="yao kong fu gui"){
         serialport2.write('01 05 09 02 FF 00 2E 66','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="yao kong gu zhang lu bo zhong qi"){
         serialport2.write('01 05 09 03 FF 00 7F A6','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="jia re chu shi chu kou ming ling"){
         serialport2.write('01 05 09 0A FF 00 AF A4','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="shi ya yan shi chu kou ming ling"){
         serialport2.write('01 05 09 0B FF 00 FE 64','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="guo liu shi yan ming ling"){
         serialport2.write('01 05 09 0C FF 00 4F A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="lou dian shi yan ming ling"){
         serialport2.write('01 05 09 0D FF 00 1E 65','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="jue yuan shi yan ming ling"){
         serialport2.write('01 05 09 0E FF 00 EE 65','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="qing dian du ming ling"){
         serialport2.write('01 05 09 0F FF 00 BF A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fang yue ji fang zhen shi yan ming ling"){
         serialport2.write('01 05 09 10 FF 00 8E 63','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="GSEgao jing fu gui ming ling"){
         serialport2.write('01 05 09 11 FF 00 DF A3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="SU31kai chu 1"){
         serialport2.write('01 05 09 12 FF 00 2F A3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="SU31kai chu 2"){
         serialport2.write('01 05 09 13 FF 00 7E 63','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="SU31kai chu 3"){
         serialport2.write('01 05 09 14 FF 00 CF A2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="SU31kai chu 4"){
         serialport2.write('01 05 09 15 FF 00 9E 62','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="suo you lu bo zhong chuan ming ling"){
         serialport2.write('01 05 09 16 FF 00 6E 62','hex');
         return res.send("Led light is on!!!");
    }


//��¼11

//��¼12
  if(action =="fu lu 12Axiang bao hu dian liu"){
         serialport2.write('01 03 0A 00 00 01 87 D2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Cxiang bao hu dian liu"){
         serialport2.write('01 03 0A 01 00 01 D6 12','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Axiang ce liang dian liu"){
         serialport2.write('01 03 0A 02 00 01 26 12','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Bxiang ce liang dian liu"){
         serialport2.write('01 03 0A 03 00 01 77 D2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Cxiang ce liang dian liu"){
         serialport2.write('01 03 0A 04 00 01 C6 13','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Axiang ce liang dian ya"){
         serialport2.write('01 03 0A 05 00 01 97 D3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Bxiang ce liang dian ya"){
         serialport2.write('01 03 0A 06 00 01 67 D3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Cxiang ce liang dian ya"){
         serialport2.write('01 03 0A 07 00 01 36 13','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12ABxian ce liang dian ya"){
         serialport2.write('01 03 0A 08 00 01 06 10','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12BCxian ce liang dian ya"){
         serialport2.write('01 03 0A 09 00 01 57 D0','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12CAxian ce liang dian ya"){
         serialport2.write('01 03 0A 0A 00 01 A7 D0','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12ling xu bao hu dian ya"){
         serialport2.write('01 03 0A 0B 00 01 F6 10','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12ling xu bao hu dian liu"){
         serialport2.write('01 03 0A 0C 00 01 47 D1','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Bxiang bao hu dian liu"){
         serialport2.write('01 03 0D 0C 00 01 46 A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12jue yuan dian zu"){
         serialport2.write('01 03 0D 0E 00 01 E7 65','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12bei yong"){
         serialport2.write('01 03 0D 0F 00 01 B6 A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 12Axiang bao hu dian liu"){
         serialport2.write('01 03 0A 00 00 01 87 D2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="kuo zhan gong neng shi neng"){
         serialport2.write('01 03 0D 10 00 01 87 63','hex');
         return res.send("Led light is on!!!");
    }


//��¼13

//��¼14
  if(action =="ben ji IP-H"){
         serialport2.write('01 03 0C 00 00 01 87 5A','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="ben ji IP-L"){
         serialport2.write('01 03 0C 01 00 01 D6 9A','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="ben ji zi wang yan ma -H"){
         serialport2.write('01 03 0C 02 00 01 26 9A','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="ben ji zi wang yan ma -L"){
         serialport2.write('01 03 0C 03 00 01 77 5A','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="ben ji wang guan -H"){
         serialport2.write('01 03 0C 04 00 01 C6 9B','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="ben ji wang guan -L"){
         serialport2.write('01 03 0C 05 00 01 97 5B','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song shu mu"){
         serialport2.write('01 03 0C 06 00 01 67 5B','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song shu mu"){
         serialport2.write('01 03 0C 07 00 01 36 9B','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP1-H"){
         serialport2.write('01 03 0C 08 00 01 06 98','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP1-L"){
         serialport2.write('01 03 0C 09 00 01 57 58','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP2-H"){
         serialport2.write('01 03 0C 0A 00 01 A7 58','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP2-L"){
         serialport2.write('01 03 0C 0B 00 01 F6 98','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP3-H"){
         serialport2.write('01 03 0C 0C 00 01 47 59','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP3-L"){
         serialport2.write('01 03 0C 0D 00 01 16 99','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP4-H"){
         serialport2.write('01 03 0C 0E 00 01 E6 99','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP4-L"){
         serialport2.write('01 03 0C 0F 00 01 B7 59','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP5-H"){
         serialport2.write('01 03 0C 10 00 01 86 9F','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP5-L"){
         serialport2.write('01 03 0C 11 00 01 D7 5F','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP6-H"){
         serialport2.write('01 03 0C 12 00 01 27 5F','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="zheng xiang fa song IP6-L"){
         serialport2.write('01 03 0C 13 00 01 76 9F','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP1-H"){
         serialport2.write('01 03 0C 14 00 01 C7 5E','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP1-L"){
         serialport2.write('01 03 0C 15 00 01 96 9E','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP2-H"){
         serialport2.write('01 03 0C 16 00 01 66 9E','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP2-L"){
         serialport2.write('01 03 0C 17 00 01 37 5E','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP3-H"){
         serialport2.write('01 03 0C 18 00 01 07 5D','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP3-L"){
         serialport2.write('01 03 0C 19 00 01 56 9D','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP4-H"){
         serialport2.write('01 03 0C 1A 00 01 A6 9D','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fan xiang fa song IP4-L"){
         serialport2.write('01 03 0C 1B 00 01 F7 5D','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fan xiang fa song IP5-H"){
         serialport2.write('01 03 0C 1C 00 01 46 9C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fan xiang fa song IP5-L"){
         serialport2.write('01 03 0C 1D 00 01 17 5C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fan xiang fa song IP6-H"){
         serialport2.write('01 03 0C 1E 00 01 E7 5C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fan xiang fa song IP6-L"){
         serialport2.write('01 03 0C 1F 00 01 B6 9C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="ben ji wang kou duan kou hao"){
         serialport2.write('01 03 0C 20 00 01 86 90','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="fu lu 14bei yong 1"){
         serialport2.write('01 03 0C 21 00 01 D7 50','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="shang ji shi ben ji xing hao"){
         serialport2.write('01 03 0C 22 00 01 27 50','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="fu lu 14bei yong 2"){
         serialport2.write('01 03 0C 23 00 01 76 90','hex');
         return res.send("Led light is on!!!");
    }

//��¼15
  if(action =="Ia  2ci xie bo"){
         serialport2.write('01 03 0D 00 00 01 86 A6','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  2ci xie bo"){
         serialport2.write('01 03 0D 01 00 01 D7 66','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  2ci xie bo"){
         serialport2.write('01 03 0D 02 00 01 27 66','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  2ci xie bo"){
         serialport2.write('01 03 0D 03 00 01 76 A6','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  2ci xie bo"){
         serialport2.write('01 03 0D 04 00 01 C7 67','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  2ci xie bo"){
         serialport2.write('01 03 0D 05 00 01 96 A7','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  3ci xie bo"){
         serialport2.write('01 03 0D 06 00 01 66 A7','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  3ci xie bo"){
         serialport2.write('01 03 0D 07 00 01 37 67','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  3ci xie bo"){
         serialport2.write('01 03 0D 08 00 01 07 64','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  3ci xie bo"){
         serialport2.write('01 03 0D 09 00 01 56 A4','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  3ci xie bo"){
         serialport2.write('01 03 0D 0A 00 01 A6 A4','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  3ci xie bo"){
         serialport2.write('01 03 0D 0B 00 01 F7 64','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  4ci xie bo"){
         serialport2.write('01 03 0D 0C 00 01 46 A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  4ci xie bo"){
         serialport2.write('01 03 0D 0D 00 01 17 65','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  4ci xie bo"){
         serialport2.write('01 03 0D 0E 00 01 E7 65','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  4ci xie bo"){
         serialport2.write('01 03 0D 0F 00 01 B6 A5','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  4ci xie bo"){
         serialport2.write('01 03 0D 10 00 01 87 63','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  4ci xie bo"){
         serialport2.write('01 03 0D 11 00 01 D6 A3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  5ci xie bo"){
         serialport2.write('01 03 0D 12 00 01 26 A3','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  5ci xie bo"){
         serialport2.write('01 03 0D 13 00 01 77 63','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  5ci xie bo"){
         serialport2.write('01 03 0D 14 00 01 C6 A2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  5ci xie bo"){
         serialport2.write('01 03 0D 15 00 01 97 62','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  5ci xie bo"){
         serialport2.write('01 03 0D 16 00 01 67 62','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  5ci xie bo"){
         serialport2.write('01 03 0D 17 00 01 36 A2','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  6ci xie bo"){
         serialport2.write('01 03 0D 18 00 01 06 A1','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  6ci xie bo"){
         serialport2.write('01 03 0D 19 00 01 57 61','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  6ci xie bo"){
         serialport2.write('01 03 0D 1A 00 01 A7 61','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  6ci xie bo"){
         serialport2.write('01 03 0D 1B 00 01 F6 A1','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  6ci xie bo"){
         serialport2.write('01 03 0D 1C 00 01 47 60','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  6ci xie bo"){
         serialport2.write('01 03 0D 1D 00 01 16 A0','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  7ci xie bo"){
         serialport2.write('01 03 0D 1E 00 01 E6 A0','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  7ci xie bo"){
         serialport2.write('01 03 0D 1F 00 01 B7 60','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  7ci xie bo"){
         serialport2.write('01 03 0D 20 00 01 87 6C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  7ci xie bo"){
         serialport2.write('01 03 0D 21 00 01 D6 AC','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  7ci xie bo"){
         serialport2.write('01 03 0D 22 00 01 26 AC','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  7ci xie bo"){
         serialport2.write('01 03 0D 23 00 01 77 6C','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  9ci xie bo"){
         serialport2.write('01 03 0D 24 00 01 C6 AD','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  9ci xie bo"){
         serialport2.write('01 03 0D 25 00 01 97 6D','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  9ci xie bo"){
         serialport2.write('01 03 0D 26 00 01 67 6D','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  9ci xie bo"){
         serialport2.write('01 03 0D 27 00 01 36 AD','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  9ci xie bo"){
         serialport2.write('01 03 0D 28 00 01 06 AE','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  9ci xie bo"){
         serialport2.write('01 03 0D 29 00 01 57 6E','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  11ci xie bo"){
         serialport2.write('01 03 0D 2A 00 01 A7 6E','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  11ci xie bo"){
         serialport2.write('01 03 0D 2B 00 01 F6 AE','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  11ci xie bo"){
         serialport2.write('01 03 0D 2C 00 01 47 6F','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  11ci xie bo"){
         serialport2.write('01 03 0D 2D 00 01 16 AF','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  11ci xie bo"){
         serialport2.write('01 03 0D 2E 00 01 E6 AF','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  11ci xie bo"){
         serialport2.write('01 03 0D 2F 00 01 B7 6F','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  13ci xie bo"){
         serialport2.write('01 03 0D 30 00 01 86 A9','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  13ci xie bo"){
         serialport2.write('01 03 0D 31 00 01 D7 69','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  13ci xie bo"){
         serialport2.write('01 03 0D 32 00 01 27 69','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  13ci xie bo"){
         serialport2.write('01 03 0D 33 00 01 76 A9','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ub  13ci xie bo"){
         serialport2.write('01 03 0D 34 00 01 C7 68','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Uc  13ci xie bo"){
         serialport2.write('01 03 0D 35 00 01 96 A8','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ia  zong ji bian lue"){
         serialport2.write('01 03 0D 36 00 01 66 A8','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ib  zong ji bian lue"){
         serialport2.write('01 03 0D 37 00 01 37 68','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ic  zong ji bian lue"){
         serialport2.write('01 03 0D 38 00 01 07 6B','hex');
         return res.send("Led light is on!!!");
    }
  if(action =="Ua  zong ji bian lue"){
         serialport2.write('01 03 0D 39 00 01 56 AB','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="Ub  zong ji bian lue"){
         serialport2.write('01 03 0D 3A 00 01 A6 AB','hex');
         return res.send("Led light is on!!!");
    }

  if(action =="Uc  zong ji bian lue"){
         serialport2.write('01 03 0D 3B 00 01 F7 6B','hex');
         return res.send("Led light is on!!!");
    }






    if(action =='off') {
        serialport2.write("off");
        return res.send("Led light is off!");
    }

    if(action =='off') {
        serialport2.write("off");
        return res.send("Led light is off!");
    }

    return res.send('Action:'+ action);

});







app.listen(port, function () {
  console.log('Example app listening on port http://127.0.0.1:'+ port +'!');
});
