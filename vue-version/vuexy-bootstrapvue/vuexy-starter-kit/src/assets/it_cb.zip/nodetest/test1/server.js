const { SerialPort } = require('serialport')
//  baudRate: 921600, autoOpen:false 
const port2 = new SerialPort({ path: 'COM2', baudRate: 921600}, function (err) {
  if (err) {
    return console.log('Error: ', err.message)
  }
})

port2.write('main screen turn on', function(err) {
  if (err) {
    return console.log('Error on write: ', err.message)
  }
  console.log('message written')
})


//发hex
var senddata = [0x01,0x02];
//发字符串
//senddata = 'test data';

function writeport()
{
    port2.write(senddata, function (err) {
        if (err) {
            return console.log('Error on write: ', err.message);
        }
        console.log('send: ' + senddata);
    });
}

port2.on('open', function () {
    writeport();
});

// open errors will be emitted as an error event
port2.on('error', function (err) {
    console.log('Error: ', err.message);
})

setInterval(function () {
    writeport();
}, 5000);


port2.on('data', function (data) {
    //收hex
    // console.log('recv: ' + data.toString('hex'));
    //收字符串
    console.log('recv: ' + data );
  });
 