const express = require('express');
const app = express();
const cors = require("cors")
const { SerialPort } = require('serialport')
const serialport2 = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 115200}, function (err) {
  if (err) {
    return console.log('Error: ', err.message)
  }
})


var port = 10866;

// var arduinoCOMPort ="COM2";

// var serialport2 = new SerialPort(arduinoCOMPort, {
//  baudrate: 921600
// });


app.use(
    cors({
        origin: ["http://localhost:10866","http://localhost:8080","http://192.168.0.109:8080","http://192.168.3.103:8080"]
    })
);


function hex(str) {
        var arr = [];
        for (var i = 0, l = str.length; i < l; i ++) {
                var ascii = str.charCodeAt(i);
                arr.push(ascii);
        }
        arr.push(255);
        arr.push(255);
        arr.push(255);
        return new Buffer(arr);
}


serialport2.write('main screen turn on', function(err) {
  if (err) {
    return console.log('Error on write:', err.message)
  }
  console.log('message written')
})


//��hex
var senddata = [0x01,0x02];
//���ַ���
//senddata ='test data';

function writeport()
{
    serialport2.write(senddata, function (err) {
        if (err) {
            return console.log('Error on write:', err.message);
        }
        console.log('send:'+ senddata);
    });
}

serialport2.on('open', function () {
    writeport();
});

// open errors will be emitted as an error event
serialport2.on('error', function (err) {
    console.log('Error:', err.message);
})

// setInterval(function () {
//     writeport();
// }, 1000);


serialport2.on('data', function (data) {
    //��hex
    // console.log('recv:'+ data.toString('hex','hex');
    //���ַ���
    console.log('recv:'+ data );
  });



serialport2.on('open',function() {
  console.log('Serial Port'+' ttyUSB0 '+'is opened.');
});

app.get('/', function (req, res) {

    return res.send('Working');

})

app.get('/:action', function (req, res) {

   var action = req.params.action || req.param('action');

    if(action =='led'){
        serialport2.write("ledget");
         return res.send("Led light is on!!!");

    }
    if(action =='off') {
        serialport2.write("off");
        return res.send("Led light is off!");
    }

    return res.send('Action:'+ action);

});

app.post('/:action', function (req, res) {

   var action = req.params.action || req.param('action');

if(action =='led2'){
 serialport2.write("ledget");
 return res.send("Led light is on!!!");
}

if(action =='led'){
 serialport2.write('01 05 09 00 FF 00 8F A6','hex');
 return res.send("Led light is on!!!");
}


//��¼1

if(action=="dianliuhuganqibianbi"){
serialport2.write('010300000001840A','hex');
return res.send("Ledlightison!!!");
}
if(action=="pingbaocanshushezhi"){
serialport2.write('010300010001D5CA','hex');
return res.send("Ledlightison!!!");
}

if(action=="dianyahuganqibianbi"){
serialport2.write('01030002000125CA','hex');
return res.send("Ledlightison!!!");
}
if(action=="hezhajidianqimochongkuandu"){
serialport2.write('010300030001740A','hex');
return res.send("Ledlightison!!!");
}
if(action=="tiaozhajidianqimochongkuandu"){
serialport2.write('010300040001C5CB','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang1lueboshijian"){
serialport2.write('010300050001940B','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang2lueboshijian"){
serialport2.write('010300060001640B','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang3lueboshijian"){
serialport2.write('01030007000135CB','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang4lueboshijian"){
serialport2.write('01030008000105C8','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang5lueboshijian"){
serialport2.write('0103000900015408','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang6lueboshijian"){
serialport2.write('0103000A0001A408','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang7lueboshijian"){
serialport2.write('0103000B0001F5C8','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairuliang8lueboshijian"){
serialport2.write('0103000C00014409','hex');
return res.send("Ledlightison!!!");
}
if(action=="CANtongxunbotelue"){
serialport2.write('0103000D000115C9','hex');
return res.send("Ledlightison!!!");
}
if(action=="CANtongxundizhi"){
serialport2.write('0103000E0001E5C9','hex');
return res.send("Ledlightison!!!");
}
if(action=="RS485botelue"){
serialport2.write('0103000F0001B409','hex');
return res.send("Ledlightison!!!");
}
if(action=="RS485tongxundizhi"){
serialport2.write('01030010000185CF','hex');
return res.send("Ledlightison!!!");
}
if(action=="yougongdiandumochongjishu"){
serialport2.write('010300110001D40F','hex');
return res.send("Ledlightison!!!");
}
if(action=="wugongdiandumochongjishu"){
serialport2.write('010300120001240F','hex');
return res.send("Ledlightison!!!");
}
if(action=="guzhanglubofuguifangshi"){
serialport2.write('01030013000175CF','hex');
return res.send("Ledlightison!!!");
}
if(action=="canshushedingmima"){
serialport2.write('010300140001C40E','hex');
return res.send("Ledlightison!!!");
}
if(action=="MainCPUbanben"){
serialport2.write('01030015000195CE','hex');
return res.send("Ledlightison!!!");
}
if(action=="ComCPUbanben"){
serialport2.write('01030016000165CE','hex');
return res.send("Ledlightison!!!");
}
if(action=="dianjiqidongxuanze"){
serialport2.write('010300170001340E','hex');
return res.send("Ledlightison!!!");
}
if(action=="dianjiedingdianliu"){
serialport2.write('010300180001040D','hex');
return res.send("Ledlightison!!!");
}
if(action=="loudianjidianqimochongshijian"){
serialport2.write('01030019000155CD','hex');
return res.send("Ledlightison!!!");
}
if(action=="jueyuanjidianqimochongshijian"){
serialport2.write('0103001A0001A5CD','hex');
return res.send("Ledlightison!!!");
}
if(action=="gongluejisuanfangshi"){
serialport2.write('0103001B0001F40D','hex');
return res.send("Ledlightison!!!");
}
if(action=="danweibisuoshijian"){
serialport2.write('0103001C000145CC','hex');
return res.send("Ledlightison!!!");
}
if(action=="suduanjiesuodianliu"){
serialport2.write('0103001D0001140C','hex');
return res.send("Ledlightison!!!");
}
if(action=="jiarechushijidianqimochongshijian"){
serialport2.write('0103001E0001E40C','hex');
return res.send("Ledlightison!!!");
}
if(action=="shiyayanshijidianqimochongshijian"){
serialport2.write('0103001F0001B5CC','hex');
return res.send("Ledlightison!!!");
}
if(action=="ruanfuweicishu"){
serialport2.write('01030020000185C0','hex');
return res.send("Ledlightison!!!");
}
if(action=="yingfuweicishu"){
serialport2.write('010300210001D400','hex');
return res.send("Ledlightison!!!");
}
if(action=="beiyong1"){
serialport2.write('0103002200012400','hex');
return res.send("Ledlightison!!!");
}
if(action=="beiyong2"){
serialport2.write('01030023000175C0','hex');
return res.send("Ledlightison!!!");
}
if(action=="guzhangbiaozhixinxi"){
serialport2.write('010300240001C401','hex');
return res.send("Ledlightison!!!");
}
if(action=="PDPbanbenxinxi"){
serialport2.write('010300250006D403','hex');
return res.send("Ledlightison!!!");
}
if(action=="ComBootbanbenxinxi"){
serialport2.write('0103002B0001F402','hex');
return res.send("Ledlightison!!!");
}
if(action=="yejingduibidu"){
serialport2.write('0103002D00011403','hex');
return res.send("Ledlightison!!!");
}
if(action=="guzhangbiaozhixinxi"){
serialport2.write('0103002E0002A402','hex');
return res.send("Ledlightison!!!");
}
if(action=="hezhacishutongji"){
serialport2.write('01030058000105D9','hex');
return res.send("Ledlightison!!!");
}
if(action=="fenzhacishutongji"){
serialport2.write('0103005900015419','hex');
return res.send("Ledlightison!!!");
}
if(action=="yuanchengdianziguapai"){
serialport2.write('0103005A0001A419','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangIajixingqufan"){
serialport2.write('0103005B0001F5D9','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangIcjixingqufan"){
serialport2.write('0103005C00014418','hex');
return res.send("Ledlightison!!!");
}
if(action=="baohuIAjixingqufan"){
serialport2.write('0103005D000115D8','hex');
return res.send("Ledlightison!!!");
}
if(action=="baohuICjixingqufan"){
serialport2.write('0103005E0001E5D8','hex');
return res.send("Ledlightison!!!");
}
if(action=="zhudongfasongluboshineng"){
serialport2.write('0103005F0001B418','hex');
return res.send("Ledlightison!!!");
}
if(action=="fangyuejibisuochixushijian"){
serialport2.write('0103006000018414','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kuozhanjidianqi1chukoumochong"){
serialport2.write('010300610001D5D4','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kuozhanjidianqi2chukoumochong"){
serialport2.write('01030062000125D4','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kuozhanjidianqi3chukoumochong"){
serialport2.write('0103006300017414','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kuozhanjidianqi4chukoumochong"){
serialport2.write('010300640001C5D5','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangIbjixingqufan"){
serialport2.write('0103006500019415','hex');
return res.send("Ledlightison!!!");
}
if(action=="baohuIBjixingqufan"){
serialport2.write('0103006600016415','hex');
return res.send("Ledlightison!!!");
}
if(action=="bentikuozhanjidianqi1chukoumochong"){
serialport2.write('01030067000135D5','hex');
return res.send("Ledlightison!!!");
}
if(action=="bentikuozhanjidianqi2chukoumochong"){
serialport2.write('01030068000105D6','hex');
return res.send("Ledlightison!!!");
}
if(action=="bentikuozhanjidianqi3chukoumochong"){
serialport2.write('0103006900015416','hex');
return res.send("Ledlightison!!!");
}
if(action=="bentikuozhanjidianqi4chukoumochong"){
serialport2.write('0103006A0001A416','hex');
return res.send("Ledlightison!!!");
}




//��¼2
if(action=="suduanbaohudianliudingzhi"){
serialport2.write('01030100000185F6','hex');
return res.send("Ledlightison!!!");
}
if(action=="xianshisuduanbaohudianliudingzhi"){
serialport2.write('010301010001D436','hex');
return res.send("Ledlightison!!!");
}
if(action=="xianshisuduanbaohushijiandingzhi"){
serialport2.write('0103010200012436','hex');
return res.send("Ledlightison!!!");
}
if(action=="dingshixianguoliubaohudianliudingzhi"){
serialport2.write('01030103000175F6','hex');
return res.send("Ledlightison!!!");
}
if(action=="dingshixianguoliubaohushijiandingzhi"){
serialport2.write('010301040001C437','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanshixianguoliubaohudianliudingzhi"){
serialport2.write('01030105000195F7','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanshixianguoliubaohushijianbeishu"){
serialport2.write('01030106000165F7','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanshixianquxianzhonglei"){
serialport2.write('0103010700013437','hex');
return res.send("Ledlightison!!!");
}
if(action=="lingxuguoliubaohudianliudingzhi"){
serialport2.write('0103010800010434','hex');
return res.send("Ledlightison!!!");
}
if(action=="lingxuguoliubaohushijiandingzhi"){
serialport2.write('01030109000155F4','hex');
return res.send("Ledlightison!!!");
}
if(action=="NULL1"){
serialport2.write('0103010A0001A5F4','hex');
return res.send("Ledlightison!!!");
}
if(action=="NULL2"){
serialport2.write('0103010B0001F434','hex');
return res.send("Ledlightison!!!");
}
if(action=="gongluefangxianglingxuguoliubaohudingzhi"){
serialport2.write('0103010C000145F5','hex');
return res.send("Ledlightison!!!");
}
if(action=="gongluefangxianglingxuguoliubaohushijian"){
serialport2.write('0103010D00011435','hex');
return res.send("Ledlightison!!!");
}
if(action=="didianyabaohudianyadingzhi"){
serialport2.write('0103010E0001E435','hex');
return res.send("Ledlightison!!!");
}
if(action=="didianyabaohushijiandingzhi"){
serialport2.write('0103010F0001B5F5','hex');
return res.send("Ledlightison!!!");
}
if(action=="guodianyabaohudianyadingzhi"){
serialport2.write('0103011000018433','hex');
return res.send("Ledlightison!!!");
}
if(action=="guodianyabaohushijiandingzhi"){
serialport2.write('010301110001D5F3','hex');
return res.send("Ledlightison!!!");
}
if(action=="lingxuguodianyabaohudianyadingzhi"){
serialport2.write('01030112000125F3','hex');
return res.send("Ledlightison!!!");
}
if(action=="jueyuandianzujiancedianzudidingzhi"){
serialport2.write('010301140001C5F2','hex');
return res.send("Ledlightison!!!");
}
if(action=="jueyuandianzujiancedianzugaodingzhi"){
serialport2.write('0103011500019432','hex');
return res.send("Ledlightison!!!");
}
if(action=="jueyuandianzujianceshijiandingzhi"){
serialport2.write('0103011600016432','hex');
return res.send("Ledlightison!!!");
}
if(action=="PTduanxianbaojingyanshishijian"){
serialport2.write('01030117000135F2','hex');
return res.send("Ledlightison!!!");
}
if(action=="kairubaohuyanshidingzhi"){
serialport2.write('01030118000105F1','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu2NULL"){
serialport2.write('0103011900015431','hex');
return res.send("Ledlightison!!!");
}
if(action=="gaowentiaozhabaohuwendudingzhi"){
serialport2.write('0103011A0001A431','hex');
return res.send("Ledlightison!!!");
}
if(action=="gaowentiaozhabaohushijian"){
serialport2.write('0103011B0001F5F1','hex');
return res.send("Ledlightison!!!");
}
if(action=="jiarechushibaohushidudingzhi"){
serialport2.write('0103011C00014430','hex');
return res.send("Ledlightison!!!");
}
if(action=="shiyabaohudianyadingzhi"){
serialport2.write('0103011D000115F0','hex');
return res.send("Ledlightison!!!");
}
if(action=="shiyabaohushijiandingzhi"){
serialport2.write('0103011E0001E5F0','hex');
return res.send("Ledlightison!!!");
}
if(action=="xianquanjiedilingxuguoliubaohudingzhi"){
serialport2.write('0103011F0001B430','hex');
return res.send("Ledlightison!!!");
}
if(action=="xianquanjiedilingxuguoliubaohushijian"){
serialport2.write('010301200001843C','hex');
return res.send("Ledlightison!!!");
}
if(action=="xianquanjiedilingxuguoyabaohudingzhi"){
serialport2.write('010301210001D5FC','hex');
return res.send("Ledlightison!!!");
}
if(action=="gongluefangxiangbisuolingxu"){
serialport2.write('01030122000125FC','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu2beiyong"){
serialport2.write('010301230001743C','hex');
return res.send("Ledlightison!!!");
}
if(action=="2cixiebobisuosuduan"){
serialport2.write('010301240001C5FD','hex');
return res.send("Ledlightison!!!");
}
if(action=="2cixiebobisuoxianshisuduan"){
serialport2.write('010301250001943D','hex');
return res.send("Ledlightison!!!");
}
if(action=="2cixiebobisuodingshixianguoliu"){
serialport2.write('010301260001643D','hex');
return res.send("Ledlightison!!!");
}
if(action=="ercixiebobisuoxishu"){
serialport2.write('01030127000135FD','hex');
return res.send("Ledlightison!!!");
}

//��¼3
if(action=="celiangyougongdiandu"){
serialport2.write('01030200000185B2','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangwugongdiandu"){
serialport2.write('0103020200012472','hex');
return res.send("Ledlightison!!!");
}
if(action=="mochongyougongdiandu"){
serialport2.write('010302040001C473','hex');
return res.send("Ledlightison!!!");
}
if(action=="mochongwugongdiandu"){
serialport2.write('01030206000165B3','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangjianyougongdiandu"){
serialport2.write('0103020800010470','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangjianwugongdiandu"){
serialport2.write('0103020A0001A5B0','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangfengyougongdiandu"){
serialport2.write('0103020C000145B1','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangfengwugongdiandu"){
serialport2.write('0103020E0001E471','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangguyougongdiandu"){
serialport2.write('0103021000018477','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangguwugongdiandu"){
serialport2.write('01030212000125B7','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangpingyougongdiandu"){
serialport2.write('010302140001C5B6','hex');
return res.send("Ledlightison!!!");
}
if(action=="celiangpingwugongdiandu"){
serialport2.write('0103021600016476','hex');
return res.send("Ledlightison!!!");
}

//��¼4




//��¼5
if(action=="di0cishijianma"){
serialport2.write('010304000001853A','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianfanhuizhi"){
serialport2.write('010304010001D4FA','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����haomiao"){
serialport2.write('01030402000124FA','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����fenzhong"){
serialport2.write('010304030001753A','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����xiaoshi"){
serialport2.write('010304040001C4FB','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����guzhanglubohao��dizijie��+riqi��dizijie��"){
serialport2.write('010304050001953B','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����guzhanglubohao��gaozijie��+yue��dizijie��"){
serialport2.write('010304060001653B','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����nian"){
serialport2.write('01030407000134FB','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianma"){
serialport2.write('010304F000018509','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianfanhuizhi"){
serialport2.write('010304F10001D4C9','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����haomiao"){
serialport2.write('010304F2000124C9','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����fenzhong"){
serialport2.write('010304F300017509'),'hex';
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����xiaoshi"){
serialport2.write('010304F40001C4C8','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����guzhanglubohao��dizijie��+riqi��dizijie��"){
serialport2.write('010304F500019508','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����guzhanglubohao��gaozijie��+yue��dizijie��"){
serialport2.write('010304F600016508','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����nian"){
serialport2.write('010304F7000134C8','hex');
return res.send("Ledlightison!!!");
}
if(action=="dangqianzuixinshijianzhizhen"){
serialport2.write('010304F8000104CB','hex');
return res.send("Ledlightison!!!");
}

//��¼6

if(action=="di0cixitongshijianma"){
serialport2.write('01030500000184C6','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0ciguzhangfanhuizhi"){
serialport2.write('010305010001D506','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0ciguzhangshijian����miao"){
serialport2.write('0103050200012506','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0ciguzhangshijian����fenzhong"){
serialport2.write('01030503000174C6','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0ciguzhangshijian����xiaoshi"){
serialport2.write('010305040001C507','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����guzhanglubohao��dizijie��+riqi��dizijie��"){
serialport2.write('01030505000194C7','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0cishijianshijian����guzhanglubohao��gaozijie��+yue��dizijie��"){
serialport2.write('01030506000164C7','hex');
return res.send("Ledlightison!!!");
}
if(action=="di0ciguzhangshijian����nian"){
serialport2.write('0103050700013507','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangma"){
serialport2.write('010305F0000184F5','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangfanhuizhi"){
serialport2.write('010305F10001D535','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangshijian����miao"){
serialport2.write('010305F200012535','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangshijian����fenzhong"){
serialport2.write('010305F3000174F5','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangshijian����xiaoshi"){
serialport2.write('010305F40001C534','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����guzhanglubohao��dizijie��+riqi��dizijie��"){
serialport2.write('010305F5000194F4','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30cishijianshijian����guzhanglubohao��gaozijie��+yue��dizijie��"){
serialport2.write('010305F6000164F4','hex');
return res.send("Ledlightison!!!");
}
if(action=="di30ciguzhangshijian����nian"){
serialport2.write('010305F700013534','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu6dangqianzuixinshijianzhizhen"){
serialport2.write('010305F800010537','hex');
return res.send("Ledlightison!!!");
}

//��¼7
if(action=="Axiangceliangdianliu"){
serialport2.write('0103060000018482','hex');
return res.send("Ledlightison!!!");
}
if(action=="Bxiangceliangdianliu"){
serialport2.write('010306010001D542','hex');
return res.send("Ledlightison!!!");
}
if(action=="Cxiangceliangdianliu"){
serialport2.write('0103060200012542','hex');
return res.send("Ledlightison!!!");
}
if(action=="Axiangceliangdianya"){
serialport2.write('0103060300017482','hex');
return res.send("Ledlightison!!!");
}
if(action=="Bxiangceliangdianya"){
serialport2.write('010306040001C543','hex');
return res.send("Ledlightison!!!");
}
if(action=="Cxiangceliangdianya"){
serialport2.write('0103060500019483','hex');
return res.send("Ledlightison!!!");
}
if(action=="ABxianceliangdianya"){
serialport2.write('0103060600016483','hex');
return res.send("Ledlightison!!!");
}
if(action=="BCxianceliangdianya"){
serialport2.write('0103060700013543','hex');
return res.send("Ledlightison!!!");
}
if(action=="CAxianceliangdianya"){
serialport2.write('0103060800010540','hex');
return res.send("Ledlightison!!!");
}
if(action=="U0celiangdianya"){
serialport2.write('0103060900015480','hex');
return res.send("Ledlightison!!!");
}
if(action=="loudianceliangdianliu"){
serialport2.write('0103060A0001A480','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu7celiangyougonggonglue"){
serialport2.write('0103060B0001F540','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu7celiangwugonggonglue"){
serialport2.write('0103060C00014481','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu7celiangshizaigonglue"){
serialport2.write('0103060D00011541','hex');
return res.send("Ledlightison!!!");
}

//��¼8

//��¼9

//��¼10
if(action=="yaokonghezha"){
serialport2.write('01050900FF008FA6','hex');
return res.send("hezha!!!");
}
if(action=="yaokongfenzha"){
serialport2.write('01050901FF00DE66','hex');
return res.send("Ledlightison!!!");
}
if(action=="yaokongfugui"){
serialport2.write('01050902FF002E66','hex');
return res.send("Ledlightison!!!");
}
if(action=="yaokongguzhanglubozhongqi"){
serialport2.write('01050903FF007FA6','hex');
return res.send("Ledlightison!!!");
}
if(action=="jiarechushichukoumingling"){
serialport2.write('0105090AFF00AFA4','hex');
return res.send("Ledlightison!!!");
}
if(action=="shiyayanshichukoumingling"){
serialport2.write('0105090BFF00FE64','hex');
return res.send("Ledlightison!!!");
}
if(action=="guoliushiyanmingling"){
serialport2.write('0105090CFF004FA5','hex');
return res.send("Ledlightison!!!");
}
if(action=="loudianshiyanmingling"){
serialport2.write('0105090DFF001E65','hex');
return res.send("Ledlightison!!!");
}
if(action=="jueyuanshiyanmingling"){
serialport2.write('0105090EFF00EE65','hex');
return res.send("Ledlightison!!!");
}
if(action=="qingdiandumingling"){
serialport2.write('0105090FFF00BFA5','hex');
return res.send("Ledlightison!!!");
}
if(action=="fangyuejifangzhenshiyanmingling"){
serialport2.write('01050910FF008E63','hex');
return res.send("Ledlightison!!!");
}
if(action=="GSEgaojingfuguimingling"){
serialport2.write('01050911FF00DFA3','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kaichu1"){
serialport2.write('01050912FF002FA3','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kaichu2"){
serialport2.write('01050913FF007E63','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kaichu3"){
serialport2.write('01050914FF00CFA2','hex');
return res.send("Ledlightison!!!");
}
if(action=="SU31kaichu4"){
serialport2.write('01050915FF009E62','hex');
return res.send("Ledlightison!!!");
}
if(action=="suoyoulubozhongchuanmingling"){
serialport2.write('01050916FF006E62','hex');
return res.send("Ledlightison!!!");
}


//��¼11

//��¼12
if(action=="fulu12Axiangbaohudianliu"){
serialport2.write('01030A00000187D2','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Cxiangbaohudianliu"){
serialport2.write('01030A010001D612','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Axiangceliangdianliu"){
serialport2.write('01030A0200012612','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Bxiangceliangdianliu"){
serialport2.write('01030A03000177D2','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Cxiangceliangdianliu"){
serialport2.write('01030A040001C613','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Axiangceliangdianya"){
serialport2.write('01030A05000197D3','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Bxiangceliangdianya"){
serialport2.write('01030A06000167D3','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Cxiangceliangdianya"){
serialport2.write('01030A0700013613','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12ABxianceliangdianya"){
serialport2.write('01030A0800010610','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12BCxianceliangdianya"){
serialport2.write('01030A09000157D0','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12CAxianceliangdianya"){
serialport2.write('01030A0A0001A7D0','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12lingxubaohudianya"){
serialport2.write('01030A0B0001F610','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12lingxubaohudianliu"){
serialport2.write('01030A0C000147D1','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Bxiangbaohudianliu"){
serialport2.write('01030D0C000146A5','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12jueyuandianzu"){
serialport2.write('01030D0E0001E765','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12beiyong"){
serialport2.write('01030D0F0001B6A5','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu12Axiangbaohudianliu"){
serialport2.write('01030A00000187D2','hex');
return res.send("Ledlightison!!!");
}
if(action=="kuozhangongnengshineng"){
serialport2.write('01030D1000018763','hex');
return res.send("Ledlightison!!!");
}


//��¼13

//��¼14
if(action=="benjiIP-H"){
serialport2.write('01030C000001875A','hex');
return res.send("Ledlightison!!!");
}

if(action=="benjiIP-L"){
serialport2.write('01030C010001D69A','hex');
return res.send("Ledlightison!!!");
}

if(action=="benjiziwangyanma-H"){
serialport2.write('01030C020001269A','hex');
return res.send("Ledlightison!!!");
}

if(action=="benjiziwangyanma-L"){
serialport2.write('01030C030001775A','hex');
return res.send("Ledlightison!!!");
}

if(action=="benjiwangguan-H"){
serialport2.write('01030C040001C69B','hex');
return res.send("Ledlightison!!!");
}

if(action=="benjiwangguan-L"){
serialport2.write('01030C050001975B','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongshumu"){
serialport2.write('01030C060001675B','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongshumu"){
serialport2.write('01030C070001369B','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP1-H"){
serialport2.write('01030C0800010698','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP1-L"){
serialport2.write('01030C0900015758','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP2-H"){
serialport2.write('01030C0A0001A758','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP2-L"){
serialport2.write('01030C0B0001F698','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP3-H"){
serialport2.write('01030C0C00014759','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP3-L"){
serialport2.write('01030C0D00011699','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP4-H"){
serialport2.write('01030C0E0001E699','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP4-L"){
serialport2.write('01030C0F0001B759','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP5-H"){
serialport2.write('01030C100001869F','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP5-L"){
serialport2.write('01030C110001D75F','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP6-H"){
serialport2.write('01030C120001275F','hex');
return res.send("Ledlightison!!!");
}

if(action=="zhengxiangfasongIP6-L"){
serialport2.write('01030C130001769F','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP1-H"){
serialport2.write('01030C140001C75E','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP1-L"){
serialport2.write('01030C150001969E','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP2-H"){
serialport2.write('01030C160001669E','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP2-L"){
serialport2.write('01030C170001375E','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP3-H"){
serialport2.write('01030C180001075D','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP3-L"){
serialport2.write('01030C190001569D','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP4-H"){
serialport2.write('01030C1A0001A69D','hex');
return res.send("Ledlightison!!!");
}

if(action=="fanxiangfasongIP4-L"){
serialport2.write('01030C1B0001F75D','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanxiangfasongIP5-H"){
serialport2.write('01030C1C0001469C','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanxiangfasongIP5-L"){
serialport2.write('01030C1D0001175C','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanxiangfasongIP6-H"){
serialport2.write('01030C1E0001E75C','hex');
return res.send("Ledlightison!!!");
}
if(action=="fanxiangfasongIP6-L"){
serialport2.write('01030C1F0001B69C','hex');
return res.send("Ledlightison!!!");
}
if(action=="benjiwangkouduankouhao"){
serialport2.write('01030C2000018690','hex');
return res.send("Ledlightison!!!");
}
if(action=="fulu14beiyong1"){
serialport2.write('01030C210001D750','hex');
return res.send("Ledlightison!!!");
}

if(action=="shangjishibenjixinghao"){
serialport2.write('01030C2200012750','hex');
return res.send("Ledlightison!!!");
}

if(action=="fulu14beiyong2"){
serialport2.write('01030C2300017690','hex');
return res.send("Ledlightison!!!");
}

//��¼15
if(action=="Ia2cixiebo"){
serialport2.write('01030D00000186A6','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib2cixiebo"){
serialport2.write('01030D010001D766','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic2cixiebo"){
serialport2.write('01030D0200012766','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua2cixiebo"){
serialport2.write('01030D03000176A6','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub2cixiebo"){
serialport2.write('01030D040001C767','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc2cixiebo"){
serialport2.write('01030D05000196A7','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia3cixiebo"){
serialport2.write('01030D06000166A7','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib3cixiebo"){
serialport2.write('01030D0700013767','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic3cixiebo"){
serialport2.write('01030D0800010764','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua3cixiebo"){
serialport2.write('01030D09000156A4','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub3cixiebo"){
serialport2.write('01030D0A0001A6A4','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc3cixiebo"){
serialport2.write('01030D0B0001F764','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia4cixiebo"){
serialport2.write('01030D0C000146A5','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib4cixiebo"){
serialport2.write('01030D0D00011765','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic4cixiebo"){
serialport2.write('01030D0E0001E765','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua4cixiebo"){
serialport2.write('01030D0F0001B6A5','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub4cixiebo"){
serialport2.write('01030D1000018763','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc4cixiebo"){
serialport2.write('01030D110001D6A3','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia5cixiebo"){
serialport2.write('01030D12000126A3','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib5cixiebo"){
serialport2.write('01030D1300017763','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic5cixiebo"){
serialport2.write('01030D140001C6A2','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua5cixiebo"){
serialport2.write('01030D1500019762','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub5cixiebo"){
serialport2.write('01030D1600016762','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc5cixiebo"){
serialport2.write('01030D17000136A2','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia6cixiebo"){
serialport2.write('01030D18000106A1','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib6cixiebo"){
serialport2.write('01030D1900015761','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic6cixiebo"){
serialport2.write('01030D1A0001A761','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua6cixiebo"){
serialport2.write('01030D1B0001F6A1','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub6cixiebo"){
serialport2.write('01030D1C00014760','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc6cixiebo"){
serialport2.write('01030D1D000116A0','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia7cixiebo"){
serialport2.write('01030D1E0001E6A0','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib7cixiebo"){
serialport2.write('01030D1F0001B760','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic7cixiebo"){
serialport2.write('01030D200001876C','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua7cixiebo"){
serialport2.write('01030D210001D6AC','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub7cixiebo"){
serialport2.write('01030D22000126AC','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc7cixiebo"){
serialport2.write('01030D230001776C','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia9cixiebo"){
serialport2.write('01030D240001C6AD','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib9cixiebo"){
serialport2.write('01030D250001976D','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic9cixiebo"){
serialport2.write('01030D260001676D','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua9cixiebo"){
serialport2.write('01030D27000136AD','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub9cixiebo"){
serialport2.write('01030D28000106AE','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc9cixiebo"){
serialport2.write('01030D290001576E','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia11cixiebo"){
serialport2.write('01030D2A0001A76E','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib11cixiebo"){
serialport2.write('01030D2B0001F6AE','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic11cixiebo"){
serialport2.write('01030D2C0001476F','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua11cixiebo"){
serialport2.write('01030D2D000116AF','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub11cixiebo"){
serialport2.write('01030D2E0001E6AF','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc11cixiebo"){
serialport2.write('01030D2F0001B76F','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ia13cixiebo"){
serialport2.write('01030D30000186A9','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ib13cixiebo"){
serialport2.write('01030D310001D769','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ic13cixiebo"){
serialport2.write('01030D3200012769','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ua13cixiebo"){
serialport2.write('01030D33000176A9','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ub13cixiebo"){
serialport2.write('01030D340001C768','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uc13cixiebo"){
serialport2.write('01030D35000196A8','hex');
return res.send("Ledlightison!!!");
}
if(action=="Iazongjibianlue"){
serialport2.write('01030D36000166A8','hex');
return res.send("Ledlightison!!!");
}
if(action=="Ibzongjibianlue"){
serialport2.write('01030D3700013768','hex');
return res.send("Ledlightison!!!");
}
if(action=="Iczongjibianlue"){
serialport2.write('01030D380001076B','hex');
return res.send("Ledlightison!!!");
}
if(action=="Uazongjibianlue"){
serialport2.write('01030D39000156AB','hex');
return res.send("Ledlightison!!!");
}

if(action=="Ubzongjibianlue"){
serialport2.write('01030D3A0001A6AB','hex');
return res.send("Ledlightison!!!");
}

if(action=="Uczongjibianlue"){
serialport2.write('01030D3B0001F76B','hex');
return res.send("Ledlightison!!!");
}



if(action=='off'){
serialport2.write("off");
return res.send("Ledlightisoff!");
}

if(action=='off'){
serialport2.write("off");
return res.send("Ledlightisoff!");
}

return res.send('Action:'+action);

});


app.listen(port,function(){
console.log('Example applistening on port http://127.0.0.1:'+port+'!');
});
