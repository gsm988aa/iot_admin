const express = require('express');
const app = express();
const cors = require("cors")
const { SerialPort } = require('serialport')
const serialport2 = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 115200}, function (err) {
  if (err) {
    return console.log('Error: ', err.message)
  }
})


var port = 10866;

// var arduinoCOMPort ="COM2";

// var serialport2 = new SerialPort(arduinoCOMPort, {
//  baudrate: 921600
// });


app.use(
    cors({
        origin: ["http://localhost:10866","http://localhost:8080","http://192.168.0.109:8080","http://192.168.3.103:8080"]
    })
);


function hex(str) {
        var arr = [];
        for (var i = 0, l = str.length; i < l; i ++) {
                var ascii = str.charCodeAt(i);
                arr.push(ascii);
        }
        arr.push(255);
        arr.push(255);
        arr.push(255);
        return new Buffer(arr);
}


serialport2.write('main screen turn on', function(err) {
  if (err) {
    return console.log('Error on write:', err.message)
  }
  console.log('message written')
})


 
var senddata = [0x01,0x02];
 
//senddata ='test data';

function writeport()
{
    serialport2.write(senddata, function (err) {
        if (err) {
            return console.log('Error on write:', err.message);
        }
        console.log('send:'+ senddata);
    });
}

serialport2.on('open', function () {
    writeport();
});

// open errors will be emitted as an error event
serialport2.on('error', function (err) {
    console.log('Error:', err.message);
})

// setInterval(function () {
//     writeport();
// }, 1000);


serialport2.on('data', function (data,res) {
 
    // console.log('recv:'+ data.toString('hex','hex');
 
    console.log('recv:'+ data );
    return res.send('geeeeeet');
});



serialport2.on('open',function() {
  console.log('Serial Port'+' ttyUSB0 '+'is opened.');
});

app.get('/', function (req, res) {

    return res.send('Working');

})

app.get('/:action', function (req, res) {

   var action = req.params.action || req.param('action');

    if(action =='led'){
        serialport2.write("ledget");
         return res.send("Led light is on!!!");

    }
    if(action =='off') {
        serialport2.write("off");
        return res.send("Led light is off!");
    }

    return res.send('Action:'+ action);

});

app.post('/:action', function (req, res) {

var action = req.params.action || req.param('action');

if(action =='led2'){
 serialport2.write("ledget");
 return res.send("Led light is on!!!");
}

if(action =='led'){
 serialport2.write('01 05 09 00 FF 00 8F A6','hex');
 return res.send("Led light is on!!!");
}

 
//��¼10
if(action=="yaokonghezha"){
serialport2.write('01050900FF008FA6','hex');
return res.send("hezha!!!");
}
if(action=="yaokongfenzha"){
serialport2.write('01050901FF00DE66','hex');
return res.send("Ledlightison!!!");
}
if(action=="yaokongfugui"){
serialport2.write('01050902FF002E66','hex');
return res.send("Ledlightison!!!");
}

  
if(action=='off'){
serialport2.write("off");
return res.send("Ledlightisoff!");
}

return res.send('Action:'+action);

});


app.listen(port,function(){
console.log('Example applistening on port http://127.0.0.1:'+port+'!');
});
