# pyDB
python3
pyserial
#pymysql

