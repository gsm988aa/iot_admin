
PROJECT = "1637demo"
VERSION = "1.0.0"

-- sys库是标配
local sys = require "sys"

if wdt then
    wdt.init(15000)--初始化watchdog设置为15s
    sys.timerLoopStart(wdt.feed, 10000)--10s喂一次狗
end
--[[
@module tm1637
@summary tm1637 数码管
@version 1.0
@date    2022.04.06
@author  Dozingfiretruck
@usage
--注意:因使用了sys.wait()所有api需要在协程中使用
-- 用法实例
local tm1637 = require "tm1637"
sys.taskInit(function()
    tm1637.init(1,4)
    tm1637.singleShow(0,2)
    tm1637.singleShow(1,1,true)
    tm1637.singleShow(2,3)
    tm1637.singleShow(3,6)
    while 1 do
        sys.wait(1000)
    end
end)
]]
-- require "aht10"
gpio.setDefaultPull(0)
local tm1637 = {}

if fdb.kvdb_init("env", "onchip_fdb") then
    log.info("fdb", "kv数据库初始化成功")
end

local TM1637_SCL
local TM1637_SDA

local function i2c_init(scl,sda)
    TM1637_SCL = gpio.setup(scl, 0, gpio.PULLUP)
    TM1637_SDA = gpio.setup(sda, 0, gpio.PULLUP)
end

local function i2c_strat()
    TM1637_SDA(1)
    TM1637_SCL(1)
    TM1637_SDA(0)
    TM1637_SCL(0)
    -- sys.wait(10)
end
local function i2c_send(datax)
    for i = 0, 7, 1 do
        TM1637_SCL(0)
        local mbit = bit.isset(datax, i) and 1 or 0
        TM1637_SDA(mbit)
        TM1637_SCL(1)
    end
    TM1637_SCL(0)
    TM1637_SDA(1)
    TM1637_SCL(1)
    -- mack = TM1637_SDA()
    -- if mack == 0 then TM1637_SDA(0) end
    TM1637_SDA(0)
    TM1637_SCL(0)

end
local function i2c_stop()
    TM1637_SCL(0)
    TM1637_SDA(0)
    TM1637_SCL(1)
    TM1637_SDA(1)
end

local function i2c_recv(num)
    local revData = i2c.recv(i2cid, i2cslaveaddr, num)
    return revData
end

--[[
      0
     ---
  5 |   | 1   *
     -6-      7 (on 2nd segment)
  4 |   | 2   *
     ---
      3
76543210
 ]]

            --[[   0   1    2    3    4    5    6    7    8    9    A    b    C    d    E    F    G     H    I   J    K     L    M    n    O    P    q    r    S    t    U    v    W    X    y   Z          -   * ]]
local hextable = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x3d,0x76,0x06,0x1e,0x76,0x38,0x55,0x54,0x3f,0x73,0x67,0x50,0x6d,0x78,0x3e,0x1c,0x2a,0x76,0x6e,0x5b,0x00,0x40,0x63};


--[[
TM1637显示清空
@api tm1637.clear()
@usage
tm1637.clear()
]]
function tm1637.clear()
    i2c_strat()
    i2c_send(0x40) -- 自加模式
    i2c_stop()
    i2c_strat()
    i2c_send(0xc0)
    for i = 1, 4 do i2c_send(0x00) end
    i2c_stop()
end

--[[
TM1637显示
@api tm1637.singleShow(com,date,comma)
@number com com端口号
@number date 显示数字,0-9即显示0-9,10会显示a以此类推
@bool   comma 是否带逗号或冒号
@usage
tm1637.singleShow(0,2)
tm1637.singleShow(1,1,true)
tm1637.singleShow(2,3)
tm1637.singleShow(3,6)
]]
function tm1637.singleShow(com,datey,comma)
    if com then
        i2c_strat()
        i2c_send(0x44) -- 地址模式
        i2c_stop()
        i2c_strat()
        i2c_send(0xc0+com)
        if comma then
            i2c_send(bit.bor(hextable[datey+1],0x80))
        else
            i2c_send(hextable[datey+1])
        end
        i2c_stop()
    end
end

--[[
TM1637初始化
@api tm1637.init(scl,sda)
@number scl i2c_scl
@number sda i2c_sda
@return bool   成功返回true
@usage
tm1637.init(1,4)
]]
function tm1637.init(scl,sda)
    i2c_init(scl,sda)
    sys.wait(200)
    tm1637.clear()
    i2c_strat()
    i2c_send(0x8f)
    i2c_stop()
    return true
end

local function i2c_open(id)
    if i2c.setup(id, i2c.SLOW) ~= i2c.SLOW then
        log.error("I2C.init is: ", "fail")
    end
end
local softI2C = i2c.createSoft(2,3,0x38)
-- i2c.send(softI2C, 0x5C, string.char(0x0F, 0x2F))


-- PA1 SCL   PA4 SDA
function readAHT10()
    local id = 2
    -- i2c_open(id)
    local softI2C = i2c.createSoft(2,3,0x38)

    --数值查询，发送指令0xAC, 0x22, 0x00,通过iic发送完毕之后，AHT10返回的数值是6个字节的数组
    i2c.send(softI2C, 0x38, {0xAC, 0x22, 0x00})
    --等待75毫秒以上
    --rtos.sleep(80)
    --1[状态位],2[湿度第一段],3[湿度第二段],4前四位[湿度第三段],4前四位[温度第一段],5[温度第二段],6[温度第三段]
    local data = i2c.recv(softI2C, 0x38, 6)
    -- log.info("i2cdata", #data, data:toHex())
    -- i2c.close(id)
    if #data == 6 then
        local _, _, data2, data3, data4, data5, data6 = pack.unpack(data, "b6")
        local hum = bit.bor(bit.bor(bit.lshift(data2, 12), bit.lshift(data3, 4)), bit.rshift(data4, 4))/ 1048576 * 10000
        -- log.info("hum", hum/100 )
        local tmp = bit.bor(bit.bor(bit.lshift(bit.band(data4, 0x0f), 16), bit.lshift(data5, 8)), data6) / 1048576 * 20000 - 5000
        -- log.info("tmp", tmp/100)
        --前面将数据放大了100倍，方便没有float的固件保留精度，在使用float固件时直接缩小100倍还原
        --return tmp, hum


        return tmp/100, hum/100
    else
        return 0, 0
    end
end


-- gpio.setup(0, nil,gpio.PULLUP )
-- gpio.setup(1, nil,gpio.PULLUP )
-- gpio.setup(4, nil,gpio.PULLUP )
-- gpio.setup(7, nil,gpio.PULLUP )
-- gpio.setup(27, nil,gpio.PULLUP )
gpio.setup(pin.PA12, nil,gpio.PULLUP )   --ok
gpio.setup(pin.PA11, nil,gpio.PULLUP )   --down
gpio.setup(pin.PA10, nil,gpio.PULLUP )   --up
--log.info("lcd.drawLine", lcd.drawLine(0,20,128,20,0x001F))
-- PA11 down PA10 up PA12 ok
--0左7下4中1右27上
function Dir()
    if gpio.get(pin.PA11)==0 then
        sys.wait(50)
        return -5
    elseif gpio.get(pin.PA10)==0 then
        sys.wait(50)
        return 5
    elseif gpio.get(pin.PA12)==0 then
        sys.wait(50)
        return 1
    else
        return 0
    end


end
 
count = 0
t1xhistory = 2
t1yhistory = 0
h1xhistory = 2
h1yhistory = 2


settingtimeout = 0


if fdb.kvdb_init("env", "onchip_fdb") then
    log.info("fdb  gsm", fdb.kv_get("domain"))
end

if fdb.kv_get("domain") ~= nil then
    domain = fdb.kv_get("domain") 
else
    domain = 20
end

sys.taskInit(function()

    while 1 do
        val=Dir()
        
 
        if val == 0 then
            if settingtimeout~= 0 then
               settingtimeout = settingtimeout-1
            end
            
        elseif val == 1 then
            settingtimeout = 0
        else 

            settingtimeout =10
            -- log.info("Dir",val) 
            domain = domain + val
            log.info("Domain",domain)
             
            log.info("fdb", fdb.kv_set("domain", domain))
           
        end
        sys.wait(1000)

    end

end)



sys.taskInit(function()

    tm1637.init(1,4)
    tm1637.singleShow(0,t1xhistory)
    tm1637.singleShow(1,t1yhistory,true)
    tm1637.singleShow(2,h1xhistory)
    tm1637.singleShow(3,h1yhistory)

 

    while 1 do

  
        if settingtimeout == 0 then
            if t1x >= 0 then

                    tm1637.singleShow(0,t1x)
                    tm1637.singleShow(1,t1y,true)
                    tm1637.singleShow(2,h1x)
                    tm1637.singleShow(3,h1y)
                    h1xhistory= h1x
                    h1yhistory= h1y
                    t1xhistory =t1x
                    t1yhistory =t1y
                    sys.wait(2000)
                -- end
            end
        else 

            local  s1x =  math.floor(domain/10)
            local  s1y =  math.floor(domain%10)
            -- log.info("set settingtimeout s1x s1y",settingtimeout,s1x,s1y)

            tm1637.singleShow(0,s1x)
            tm1637.singleShow(1,s1y,true)
            tm1637.singleShow(2,h1x)
            tm1637.singleShow(3,h1y)
            h1xhistory= h1x
            h1yhistory= h1y
            t1xhistory =t1x
            t1yhistory =t1y

            if settingtimeout >=1 then 
                settingtimeout = settingtimeout -1 

            end
        end
        sys.wait(1000)

    end

end)

sys.taskInit(function()
    while 1 do
        t1,h1 =readAHT10()
        t1x =  math.floor(t1/10)
        t1y =  math.floor(t1%10)
        h1x =  math.floor(h1/10)
        h1y =  math.floor(h1%10)
        sys.wait(5000)

    end

end)
sys.taskInit(function()
    while 1 do
        log.info("count t1 h1",count,t1,h1)
        
        if domain <= 0 then
            gpio.setup(pin.PA05, 0)  -- Motor on 
            gpio.setup(pin.PB02, 0)  -- led on 
            sys.wait(15000)
        else
            if h1 >= domain then
                if count <= 200 then
                    if t1x <=7 then
                        gpio.setup(pin.PA05, 0)  -- Motor on 
                        gpio.setup(pin.PB02, 0)  -- led on 
                        sys.wait(15000)
                    else 
                        count = 210
                        gpio.setup(pin.PA05, 1)  --Motor off
                        gpio.setup(pin.PB02, 1)   -- led off
                        sys.wait(3000)
                    end
                    count = count+1
                else
                    count = 0
                    gpio.setup(pin.PA05, 1)  --Motor off
                    gpio.setup(pin.PB02, 1)   -- led off
                    sys.wait(30000)
                end
             else
                gpio.setup(pin.PA05, 1)  --Motor off
                gpio.setup(pin.PB02, 1)   -- led off
                sys.wait(6000)
            end
        end
    end

end)
 
sys.run()
